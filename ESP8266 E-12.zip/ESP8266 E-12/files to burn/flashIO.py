# Created by DEEPAK KUMAR
# Copyright@ DEEPAK KUMAR
# Date 23-12-2016 

# Class for handling specific input output on the Flash memory
    # method for saving pin state on the "main_data.txt"
def saveStat(pin,stat):
    pin=str(pin)
    stat=str(stat)
    try:
        buff = open("main_data.txt")
        buff_data = buff.read()
        buff_match_index=buff_data.find("ch"+pin+"=")
        if buff_match_index == -1 :
            new_buff_data = "ch"+pin+"="+stat+","+buff_data
        else:
            current = buff_data[buff_match_index+4:buff_match_index+5]
            new_buff_data = buff_data.replace("ch"+pin+"="+current,"ch"+pin+"="+stat)
        buff.close()
        buff = open("main_data.txt",'w')
        buff.write(new_buff_data)
        buff.close()
    except Exception as e:
        if (str(e))[10:16] == "ENOENT":
            buff = open("main_data.txt",'w')
            buff.close()
            saveStat(pin,stat)



    # method for reading current status of the pin and return it 
def readStat(pin):
    pin=str(pin)
    try:
        buff = open("main_data.txt")
        buff_data = buff.read()
        buff_match_index = buff_data.find("ch"+pin+"=")
        if buff_match_index == -1 :     # If data doesn't exist then send relay off signal
            buff.close()
            return 1
        else:                           # If the data exist then return the true state
            buff.close()
            return int(buff_data[buff_match_index+4:buff_match_index+5])
    except Exception as e:              # If file doesn't exist or if any other error occures then send relay off signal
        return 1
