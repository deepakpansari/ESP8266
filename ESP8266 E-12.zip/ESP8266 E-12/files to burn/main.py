# main.py
# ESP8266-E12 module
# DEEPAK KUMAR
# 21/12/2016
# v 0.0.1
#@@ means edit acording to use
################################################################################################
# Import all necessary classes
import machine 				# Handling machine related stuffs
import socket 				# For making web server
import flashIO
import network				# Handles all type of network activity
from machine import Timer 	# For Timer interrupt

################################################################################################
# creating the pin object and assigning last value to it,by default all relay are off ie 1
# pin0 is left for other function if needed
# channel 0 ==> pin 1
# channel 1 ==> pin 3
# channel 2 ==> pin 5
# channel 3 ==> pin 4
# channel 4 ==> pin 13
# channel 5 ==> pin 12
# channel 6 ==> pin 14
# channel 7 ==> pin 16
#@@ change according to board
#@@ array index is according to channel
#@@ assign pin name in that order
pins = [1,3,5,4,13,12,14,16]
ch={}
index_pin=0
for pin in pins:
    ch[index_pin] = machine.Pin(pin,machine.Pin.OUT)	# Setting all pin as output
    ch[index_pin].value(flashIO.readStat(index_pin))	# According to the previous state, set current status 
    index_pin = index_pin + 1

################################################################################################
# timer variable 
# at a time only one timer will assigned to each channel
timer={}

################################################################################################
# on each start check if station mode is connected to any wifi network
# if connected start the server on that ip 
# otherwise create own access point and start server at 0.0.0.0:2298
sta = network.WLAN(network.STA_IF)
ap = network.WLAN(network.AP_IF)
if sta.active() == True & sta.isconnected() == True :
    ip_server = sta.ifconfig()[0]
    port_server = 2298
elif ap.active() == True :
	ip_server = ap.ifconfig()[0]
	port_server=2298							
else:
	#@@ write in the manual about this
	ap.config(essid="RooooomI",password="rooooomi")
	ap.active(True)
	ip_server = ap.ifconfig()[0]
	port_server=2298

# try to connect on the port and if any error occures then reset the machine
try:
    sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sock.bind((ip_server,port_server))
    sock.listen(5)
except Exception as e:
    machine.reset()
###############################################################################################
# Finally the loop which will execute for providing continues web server service
# no argument pass, no return value
def webserver():
    try:
        while True:
            cl, addr = sock.accept()
            # receive the data from client
            data = str(cl.recv(1024))
            # Response according to request
            if auth(data) == True:
                # response if auth ok
                #@@ change channel according to board in 
                #@@ if getVal(data,"ch") != "\0" & int(getVal(data,"ch")) < 8
                #@@ change "8" to your max no. of channels
                if getVal(data,"channel") != "\0":
                    if int(getVal(data,"channel")) < 8:
                        # channel ok now search for current status
                        if getVal(data,"status") == "on":
                            # now search for timer
                            if getVal(data,"time") != "\0":
                                # time will be in minutes
                                if getVal(data,"after") == "on":
                                    timer_index = int(getVal(data,"channel"))
                                    timer[timer_index] = Timer(timer_index)
                                    timer[timer_index].init(period=int(getVal(data,"time"))*60000, mode=Timer.ONE_SHOT, callback=lambda t:{ch[int(getVal(data,"channel"))].low(),flashIO.saveStat(getVal(data,"channel"),0)})
                                    ch[int(getVal(data,"channel"))].low()
                                    flashIO.saveStat(getVal(data,"channel"),0)
                                    cl.send("channel "+getVal(data,"channel")+" on timer set for "+getVal(data,"time")+" minutes after "+getVal(data,"after"))
                                elif getVal(data,"after") == "off":
                                    timer_index = int(getVal(data,"channel"))
                                    timer[timer_index] = Timer(timer_index)
                                    timer[timer_index].init(period=int(getVal(data,"time"))*60000, mode=Timer.ONE_SHOT, callback=lambda t:{ch[int(getVal(data,"channel"))].high(),flashIO.saveStat(getVal(data,"channel"),1)})
                                    ch[int(getVal(data,"channel"))].low()
                                    flashIO.saveStat(getVal(data,"channel"),0)
                                    cl.send("channel "+getVal(data,"channel")+" on timer set for "+getVal(data,"time")+" minutes after "+getVal(data,"after"))
                                else:
                                    cl.send("after error on channel "+getVal(data,"channel"))
                            elif getVal(data,"time")=="\0":
                                ch[int(getVal(data,"channel"))].low()
                                flashIO.saveStat(int(getVal(data,"channel")),0)
                                cl.send("channel "+getVal(data,"channel")+" on")
                            else:
                                cl.send("time error on channel "+getVal(data,"channel"))
                        elif getVal(data,"status") == "off":
                            # now search for timer
                            if getVal(data,"time") != "\0":
                                # time will be in minutes
                                if getVal(data,"after") == "on":
                                    timer_index = int(getVal(data,"channel"))
                                    timer[timer_index] = Timer(timer_index)
                                    timer[timer_index].init(period=int(getVal(data,"time"))*60000, mode=Timer.ONE_SHOT, callback=lambda t:{ch[int(getVal(data,"channel"))].low(),flashIO.saveStat(getVal(data,"channel"),0)})
                                    ch[int(getVal(data,"channel"))].high()
                                    flashIO.saveStat(getVal(data,"channel"),1)
                                    cl.send("channel "+getVal(data,"channel")+" off timer set for "+getVal(data,"time")+" minutes after "+getVal(data,"after"))
                                elif getVal(data,"after") == "off":
                                    timer_index = int(getVal(data,"channel"))
                                    timer[timer_index] = Timer(timer_index)
                                    timer[timer_index].init(period=int(getVal(data,"time"))*60000, mode=Timer.ONE_SHOT, callback=lambda t:{ch[int(getVal(data,"channel"))].high(),flashIO.saveStat(getVal(data,"channel"),1)})
                                    ch[int(getVal(data,"channel"))].high()
                                    flashIO.saveStat(getVal(data,"channel"),1)
                                    cl.send("channel "+getVal(data,"channel")+" off timer set for "+getVal(data,"time")+" minutes after "+getVal(data,"after"))
                                else:
                                    cl.send("after error on channel "+getVal(data,"channel"))
                            elif getVal(data,"time")=="\0":
                                ch[int(getVal(data,"channel"))].high()
                                flashIO.saveStat(getVal(data,"channel"),1)
                                cl.send("channel "+getVal(data,"channel")+" off")
                            else:
                                cl.send("time error on channel "+getVal(data,"channel"))
                        else:
                            cl.send("Status error on channel "+getVal(data,"channel"))
                    else:
                        cl.send("channel more than required!")                  
                # check for request 
                elif getVal(data,"request") == "reset":
                    machine.reset()
                elif getVal(data,"request") == "mode":
                    if sta.isconnected() == True :
                        cl.send("STA")
                    elif ap.isconnected() == True :
                        cl.send("AP")
                elif getVal(data,"request") == "ip":
                    if sta.isconnected() == True :
                        cl.send(sta.ifconfig()[0])
                    elif ap.isconnected() == True:
                        cl.send(ap.ifconfig()[0])
                elif getVal(data,"request") == "port":
                    cl.send(str(port_server))
                elif getVal(data,"request") == "connect":
                	cl.send("Connecting to...  ")
                	cl.send(getVal(data,"ssid"))
                	try:
                		sta.connect(getVal(data,"ssid"),getVal(data,"pass"))
                		if sta.active() == True & sta.isconnected() == True :
                			ip_server = sta.ifconfig()[0]
                			port_server = 2298
                			cl.send("---->  connected @ ")
                			cl.send(ip_server)
                			cl.send(":")
                			cl.send(port)
                		else:
                			cl.send("Error in Connection!!")
                	except Exception as e:
                		cl.send(str(e))
                else:
                    cl.send("some error occured!")
            else:
                cl.send("auth failed!!")
            cl.close()
    except Exception as e:
        cl.send(str(e))
        cl.close()
        webserver()


###############################################################################################
# Function for returing value of index in get request
# in the request string there should always be "&" in the end
# return = value of index
# arg1 = string to be searched
# arg2 = name of index to be searched
def getVal(str,index):
    index = index+"="
    if str == "\0":
        return "\0"
    else:
        index_of = str.find(index);
        if index_of == -1:
            return "\0"
        else :
            if str.find("&",index_of) == -1:
                return "\0"
            else:
                return str[index_of+len(index):str.find("&",index_of)]

##############################################################################################
# Function for authenticate user
# return = bool True or False
# arg = string to be searched
#@@ change agent name in the if getVal(str,"agent") == "2298"
def auth(str):
    if str == "\0":
        return False
    else:
        if getVal(str,"agent") == "2298" :
            return True
        else:
            return False

# Start the server
webserver()
