# main.py
# ESP8266-E12 module
# DEEPAK KUMAR
# 21/12/2016
# v 0.0.1
#@@ means edit acording to use

# This programmm has server to server method which first creates a mini server for client request
# handling. Request may be continue on AP mode or go for STA mode. On the basis of request start tyhe main server

###############################################################################################
# Function for returing value of index in get request
# in the request string there should always be "&" in the end
# return = value of index
# arg1 = string to be searched
# arg2 = name of index to be searched
def getVal(string,index):
	index = index+"="
	if string == False:
		return False
	else:
		index_of = string.find(index);
		if index_of == -1:
			return False
		else :
			if string.find("&",index_of) == -1:
				return False
			else:
				return string[index_of+len(index):string.find("&",index_of)]

##############################################################################################
# Function for authenticate user
# return = bool True or False
# arg = string to be searched
#@@ change agent name in the if getVal(str,"agent") == "2298"
def auth(str):
	if str == False:
		return False
	else:
		if getVal(str,"agent") == "2298" :
			return True
		else:
			return False
################################################################################################
# Import all necessary classes
import machine 				# Handling machine related stuffs
import socket 				# For making web server
import flashIO
import network				# Handles all type of network activity
import time

################################################################################################
# creating the pin object and assigning last value to it,by default all relay are off ie 1
# pin0 is left for other function if needed
# channel 0 ==> pin 1
# channel 1 ==> pin 3
# channel 2 ==> pin 5
# channel 3 ==> pin 4
# channel 4 ==> pin 13
# channel 5 ==> pin 12
# channel 6 ==> pin 14
# channel 7 ==> pin 16
#@@ change according to board
#@@ array index is according to channel
#@@ assign pin name in that order
pins = [1,3,5,4,13,12,14,16]
ch={}
index_pin=0
for pin in pins:
	ch[index_pin] = machine.Pin(pin,machine.Pin.OUT)	# Setting all pin as output
	ch[index_pin].value(flashIO.readStat(index_pin))	# According to the previous state, set current status 
	index_pin = index_pin + 1


################################################################################################
#  Mini Webserver for initial setupp aand commanding
# Run thee STA request twice ffor ccheckking the connection.
# If using the STAF mode  then  first run the STAF aand theen STA FOR CCONNECTTION SURITY

# Create objects for station and ap mode of wifi
sta = network.WLAN(network.STA_IF)
ap = network.WLAN(network.AP_IF)

#Start the mini  server as AP Mode
 #@@ write in the manual about this
ap.config(essid="RooooomI",password="rooooomi")
ap.active(True)
ip_server = ap.ifconfig()[0]
port_server=2298

# try to connect on the port and if any error occures then reset the machine
try:
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	sock.bind((ip_server,port_server))
	sock.listen(5)
except Exception as e:
	machine.reset()
while True:
	cl, addr = sock.accept()
	# receive the data from client
	data = str(cl.recv(1024))
	# Authentication
	if auth(data) == True:
		# response if auth ok
		# For returinig IP and PORT if connected to AP
		if getVal(data,"req") == "AP":
			ip_server=ap.ifconfig()[0]
			port_server=2298
			cl.send('IP:' +str(ip_server)+',PORT:'+str(port_server))
			# Normaal connect to STA, if already connected then give an error
		elif getVal(data,"req") == "STA" :
			if (getVal(data,"ssid") == False) | (getVal(data,"pass") == False) :
				cl.send("Put both SSID and PASS in the link")
			else:
				sta.active(True)
				if(sta.isconnected()==True):
					cl.send("Already Connected to "+str(sta.ifconfig()[0])+", Try STAF for force connect!!")
					ip_server=sta.ifconfig()[0]
				else:
					sta.connect(getVal(data,"ssid"),getVal(data,"pass"))
					if sta.isconnected() == True:
						cl.send("IP:"+str(sta.ifconfig()[0])+",PORT:"+str(port_server))
						ip_server=sta.ifconfig()[0]
					else :
						cl.send("Error Connecting @ "+getVal(data,"ssid")+":"+getVal(data,"pass"))
		 # Force CONNNECT TO STA , IF previous connection exist then disconnect and connect with new  connection
		elif getVal(data,"req") == "STAF" :
			sta.active(True)
			sta.disconnect()
			sta.connect(getVal(data,"ssid"),getVal(data,"pass"))
			if sta.isconnected() == True:
				cl.send("IP:"+str(sta.ifconfig()[0])+",PORT:"+str(port_server))
				ip_server=sta.ifconfig()[0]
			else :
				cl.send("Error Connecting @ "+getVal(data,"ssid")+":"+getVal(data,"pass"))
		elif getVal(data,"req") == "JUMP":
			cl.send("JUMPED")
			cl.close()
			sock.close()
			break
		else:
			cl.send("Error")
	else:
		cl.send("Authentication Failed!")
	cl.close()
###############################3###3#######################################################
# Now time to start the main server
# Ip can be printed using mini server by the req of AP or STA command
# Ip can also be known using the main server
# Can't connect on the same port now
port_server=2297
try:
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	sock.bind((ip_server,port_server))
	sock.listen(5)
except Exception as e:
	machine.reset()
def webserver():
	try:
		while True:
			cl, addr = sock.accept()
			# receive the data from client
			data = str(cl.recv(1024))
			# Response according to request
			if auth(data) == True:
				# response if auth ok
				#@@ change channel according to board in 
				#@@ if getVal(data,"ch") != False & int(getVal(data,"ch")) < 8
				#@@ change "8" to your max no. of channels
				if getVal(data,"channel") != False:
					if int(getVal(data,"channel")) < 8:
					# channel ok now search for current status
						if getVal(data,"status") == "on":
							ch[int(getVal(data,"channel"))].low()
							flashIO.saveStat(int(getVal(data,"channel")),0)
							cl.send("channel "+getVal(data,"channel")+" on")
						elif getVal(data,"status") == "off":
							ch[int(getVal(data,"channel"))].high()
							flashIO.saveStat(getVal(data,"channel"),1)
							cl.send("channel "+getVal(data,"channel")+" off")
						else:
							cl.send("Status error on channel "+getVal(data,"channel"))
					else:
						cl.send("channel more than required!")                  
			# check for request 
				elif getVal(data,"req") == "RESET":
					machine.reset()
				elif getVal(data,"req") == "MODE":
					if sta.isconnected() == True :
						cl.send("STA")
					elif ap.isconnected() == True :
						cl.send("AP")
				elif getVal(data,"req") == "IP":
					if sta.isconnected() == True :
						cl.send(sta.ifconfig()[0])
					elif ap.isconnected() == True:
						cl.send(ap.ifconfig()[0])
				elif getVal(data,"req") == "PORT":
					cl.send(str(port_server))
				else:
					cl.send("some error occured!")
			else:
				cl.send("auth failed!!")
			cl.close()
	except Exception as e:
		cl.send(str(e))
		cl.close()
		webserver()
# Start the server
webserver()
